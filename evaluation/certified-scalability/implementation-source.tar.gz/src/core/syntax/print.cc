#include "src/core/syntax/print.h"

#include <cstddef>
#include <functional>
#include <iomanip>
#include <ostream>
#include <sstream>
#include <string>
#include <string_view>
#include <type_traits>
#include <variant>

namespace tepl {
namespace {

void indent(std::ostream& out, int depth) {
  out << std::string(depth * 2, ' ');
}

std::string formatDimension(const syntax::ShapeDimension& dimension) {
  return std::visit(
      [](const auto& value) -> std::string {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, syntax::NamedDimension>) {
          return value.name;
        } else if constexpr (std::is_same_v<T, syntax::WildcardDimension>) {
          return "_";
        } else {
          return value.name.value_or("") + "...";
        }
      },
      dimension.value);
}

void printGraph(std::ostream& out, const syntax::GraphExpr& expression,
                int depth) {
  indent(out, depth);
  std::visit(
      [&](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, syntax::NameRef>) {
          out << "variable " << value.name << '\n';
        } else if constexpr (std::is_same_v<T, syntax::IntegerLiteral>) {
          out << "integer " << value.digits;
          if (value.dtype) out << ":" << value.dtype->name;
          out << '\n';
        } else if constexpr (std::is_same_v<T, syntax::FloatLiteral>) {
          out << "float " << value.digits;
          if (value.dtype) out << ":" << value.dtype->name;
          out << '\n';
        } else if constexpr (std::is_same_v<T, syntax::Operator>) {
          out << "operator " << value.name;
          if (value.label) out << " as " << *value.label;
          if (value.descriptor_node)
            out << " [" << *value.descriptor_node << ".attrs]";
          out << '\n';
          for (const auto& operand : value.operands) {
            printGraph(out, *operand, depth + 1);
          }
        } else if constexpr (std::is_same_v<T, syntax::Binding>) {
          out << "let " << value.binder.name << '\n';
          printGraph(out, *value.expression, depth + 1);
        } else {
          out << "get[" << value.index.digits << "]\n";
          printGraph(out, *value.tuple, depth + 1);
        }
      },
      expression.value);
}

std::string_view unarySymbol(syntax::UnaryOp op) {
  switch (op) {
    case syntax::UnaryOp::kPlus:
      return "+";
    case syntax::UnaryOp::kNegate:
      return "-";
    case syntax::UnaryOp::kLogicalNot:
      return "!";
  }
  return "?";
}

std::string_view binarySymbol(syntax::BinaryOp op) {
  switch (op) {
    case syntax::BinaryOp::kAdd:
      return "+";
    case syntax::BinaryOp::kSubtract:
      return "-";
    case syntax::BinaryOp::kMultiply:
      return "*";
    case syntax::BinaryOp::kDivide:
      return "/";
    case syntax::BinaryOp::kRemainder:
      return "%";
    case syntax::BinaryOp::kLess:
      return "<";
    case syntax::BinaryOp::kLessEqual:
      return "<=";
    case syntax::BinaryOp::kGreater:
      return ">";
    case syntax::BinaryOp::kGreaterEqual:
      return ">=";
    case syntax::BinaryOp::kEqual:
      return "==";
    case syntax::BinaryOp::kNotEqual:
      return "!=";
    case syntax::BinaryOp::kLogicalAnd:
      return "&&";
    case syntax::BinaryOp::kLogicalOr:
      return "||";
  }
  return "?";
}

void printConstraint(std::ostream& out,
                     const syntax::ConstraintExpr& expression, int depth) {
  indent(out, depth);
  std::visit(
      [&](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, syntax::NameRef>) {
          out << "name " << value.name << '\n';
        } else if constexpr (std::is_same_v<T, syntax::NodeProperty>) {
          out << "property " << value.node;
          for (const auto& part : value.path) out << "." << part;
          out << '\n';
        } else if constexpr (std::is_same_v<T, syntax::IntegerLiteral>) {
          out << "integer " << value.digits;
          if (value.dtype) out << ":" << value.dtype->name;
          out << '\n';
        } else if constexpr (std::is_same_v<T, syntax::FloatLiteral>) {
          out << "float " << value.digits;
          if (value.dtype) out << ":" << value.dtype->name;
          out << '\n';
        } else if constexpr (std::is_same_v<T, syntax::BooleanLiteral>) {
          out << "boolean " << (value.value ? "true" : "false") << '\n';
        } else if constexpr (std::is_same_v<T, syntax::Call>) {
          out << "call " << value.callee << '\n';
          for (const auto& argument : value.arguments) {
            printConstraint(out, *argument, depth + 1);
          }
        } else if constexpr (std::is_same_v<T, syntax::UnaryExpr>) {
          out << "unary " << unarySymbol(value.op) << '\n';
          printConstraint(out, *value.operand, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::BinaryExpr>) {
          out << "binary " << binarySymbol(value.op) << '\n';
          printConstraint(out, *value.lhs, depth + 1);
          printConstraint(out, *value.rhs, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::ListExpr>) {
          out << "list\n";
          for (const auto& e : value.elements)
            printConstraint(out, *e, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::IndexExpr>) {
          out << "index\n";
          printConstraint(out, *value.value, depth + 1);
          printConstraint(out, *value.index, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::ConditionalExpr>) {
          out << "if\n";
          printConstraint(out, *value.condition, depth + 1);
          printConstraint(out, *value.then_value, depth + 1);
          printConstraint(out, *value.else_value, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::ComprehensionExpr>) {
          out << "comprehension " << value.variable << '\n';
          printConstraint(out, *value.iterable, depth + 1);
          printConstraint(out, *value.element, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::LocalBinding>) {
          out << "let " << value.name << '\n';
          printConstraint(out, *value.value, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::StringLiteral>) {
          out << "string " << value.value << '\n';
        } else if constexpr (std::is_same_v<T, syntax::DescriptorConstructor>) {
          out << "descriptor";
          if (value.spread) out << " .." << *value.spread << ".attrs";
          out << '\n';
          for (const auto& f : value.fields) {
            indent(out, depth + 1);
            out << f.name << '\n';
            printConstraint(out, *f.value, depth + 2);
          }
        }
      },
      expression.value);
}

void printMetadataExpr(std::ostream& out,
                       const syntax::MetadataExpr& expression, int depth) {
  indent(out, depth);
  std::visit(
      [&](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, syntax::NameRef>) {
          out << "name " << value.name << '\n';
        } else if constexpr (std::is_same_v<T, syntax::IntegerLiteral>) {
          out << "integer " << value.digits << '\n';
        } else if constexpr (std::is_same_v<T, syntax::BooleanLiteral>) {
          out << "boolean " << (value.value ? "true" : "false") << '\n';
        } else if constexpr (std::is_same_v<T, syntax::MetadataAttrs>) {
          out << "attrs\n";
        } else if constexpr (std::is_same_v<T, syntax::MetadataCall>) {
          out << "call " << value.callee << '\n';
          for (const auto& argument : value.arguments)
            printMetadataExpr(out, *argument, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::MetadataUnary>) {
          out << "unary " << unarySymbol(value.op) << '\n';
          printMetadataExpr(out, *value.operand, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::MetadataBinary>) {
          out << "binary " << binarySymbol(value.op) << '\n';
          printMetadataExpr(out, *value.lhs, depth + 1);
          printMetadataExpr(out, *value.rhs, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::MetadataList>) {
          out << "list\n";
          for (const auto& element : value.elements)
            printMetadataExpr(out, *element, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::MetadataIndex>) {
          out << "index\n";
          printMetadataExpr(out, *value.value, depth + 1);
          printMetadataExpr(out, *value.index, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::MetadataField>) {
          out << "field " << value.field << '\n';
          printMetadataExpr(out, *value.value, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::MetadataConditional>) {
          out << "if\n";
          printMetadataExpr(out, *value.condition, depth + 1);
          indent(out, depth);
          out << "then\n";
          printMetadataExpr(out, *value.then_value, depth + 1);
          indent(out, depth);
          out << "else\n";
          printMetadataExpr(out, *value.else_value, depth + 1);
        } else if constexpr (std::is_same_v<T, syntax::MetadataComprehension>) {
          out << "comprehension " << value.variable << '\n';
          indent(out, depth + 1);
          out << "element\n";
          printMetadataExpr(out, *value.element, depth + 2);
          indent(out, depth + 1);
          out << "in\n";
          printMetadataExpr(out, *value.iterable, depth + 2);
        }
      },
      expression.value);
}

void printMetadataDefinition(std::ostream& out,
                             const syntax::MetadataDefinition& definition,
                             const char* kind = "shape") {
  out << "      " << kind << "(";
  for (std::size_t i = 0; i < definition.parameters.size(); ++i) {
    if (i != 0) out << ", ";
    const auto& parameter = definition.parameters[i];
    out << parameter.name;
    if (parameter.variadic) out << "...";
  }
  out << ")\n";
  for (const auto& statement : definition.statements) {
    std::visit(
        [&](const auto& value) {
          using T = std::decay_t<decltype(value)>;
          if constexpr (std::is_same_v<T, syntax::MetadataLet>) {
            out << "        let " << value.name << '\n';
            printMetadataExpr(out, *value.value, 5);
          } else {
            out << "        assert\n";
            printMetadataExpr(out, *value.condition, 5);
          }
        },
        statement.value);
  }
  out << "        yield\n";
  printMetadataExpr(out, *definition.result.value, 5);
}

void printDeclaration(std::ostream& out,
                      const syntax::Declaration& declaration) {
  out << "    tensor " << declaration.name << " ";
  if (declaration.dtype) out << declaration.dtype->name;
  out << "[";
  for (std::size_t index = 0; index < declaration.shape.size(); ++index) {
    if (index != 0) out << ", ";
    out << formatDimension(declaration.shape[index]);
  }
  out << "]\n";
}

void printRule(std::ostream& out, const syntax::Rule& rule) {
  out << "  " << (rule.is_abstract ? "abstract rule " : "rule ") << rule.name
      << '\n';
  for (const auto& parameter : rule.parameters) {
    out << "    parameter " << parameter.name << ": "
        << "op<(";
    for (std::size_t index = 0; index < parameter.operand_types.size();
         ++index) {
      if (index != 0) out << ", ";
      out << parameter.operand_types[index].name;
    }
    out << ") -> " << parameter.result_type.name << ">\n";
  }
  if (rule.inheritance) {
    out << "    extends " << rule.inheritance->base << '\n';
    for (const auto& binding : rule.inheritance->bindings) {
      out << "      " << binding.parameter << " = " << binding.value << '\n';
    }
  }
  for (const auto& declaration : rule.dtypes) {
    out << "    dtype " << declaration.name << '\n';
  }
  for (const auto& declaration : rule.declarations) {
    printDeclaration(out, declaration);
  }
  if (rule.lhs) {
    out << "    lhs\n";
    printGraph(out, *rule.lhs, 3);
  }
  if (rule.rhs) {
    out << "    rhs\n";
    printGraph(out, *rule.rhs, 3);
  }
  if (!rule.conditions.empty()) {
    out << "    where\n";
    for (const auto& condition : rule.conditions)
      printConstraint(out, *condition, 3);
  }
  for (const auto& derivation : rule.derivations) {
    out << (derivation.local ? "    derive let " : "    derive ")
        << derivation.target << (derivation.local ? "" : ".attrs") << '\n';
    printConstraint(out, *derivation.value, 3);
  }
}

}  // namespace

std::string formatAst(const syntax::ParsedModule& program) {
  std::ostringstream out;
  out << "program " << program.source_name << '\n';
  for (const auto& imported : program.imports) {
    if (!imported.rules.empty()) {
      out << "  from \"" << imported.path << "\" import {";
      for (std::size_t index = 0; index < imported.rules.size(); ++index) {
        if (index != 0) out << ", ";
        out << imported.rules[index].name;
      }
      out << "}\n";
    } else if (imported.dialect) {
      out << "  from \"" << imported.path << "\" import " << *imported.dialect;
      if (imported.alias && imported.alias != imported.dialect) {
        out << " as " << *imported.alias;
      }
      out << '\n';
    } else {
      out << "  import \"" << imported.path << "\"\n";
    }
  }
  for (const auto& used : program.uses) {
    out << "  use " << used.alias;
    if (!used.operations.empty()) {
      out << "::{";
      for (std::size_t index = 0; index < used.operations.size(); ++index) {
        if (index != 0) out << ", ";
        out << used.operations[index];
      }
      out << '}';
    }
    out << '\n';
  }
  for (const auto& dialect : program.dialects) {
    out << "  dialect " << dialect.name << '\n';
    for (const auto& schema : dialect.schemas) {
      out << "    attrs " << schema.name << '\n';
      for (const auto& field : schema.fields) {
        out << "      " << field.name << ": " << field.type;
        for (std::size_t i = 0; i < field.list_depth; ++i) out << "[]";
        if (field.optional) out << "?";
        if (field.empty_default) out << " = []";
        out << '\n';
      }
    }
    for (const auto& op : dialect.operations) {
      out << "    op " << op.name << '(';
      for (std::size_t index = 0; index < op.operands.size(); ++index) {
        if (index != 0) out << ", ";
        const auto& operand = op.operands[index];
        out << operand.name << ": " << operand.type;
        if (operand.variadic) out << "...";
      }
      out << ") -> " << op.result_type;
      if (op.alias) out << " alias " << *op.alias;

      if (op.attrs) {
        if (const auto* shared = std::get_if<syntax::SharedAttrs>(&*op.attrs)) {
          out << " attrs " << shared->name;
        }
      }
      out << '\n';
      if (op.attrs) {
        if (const auto* inline_attrs =
                std::get_if<syntax::InlineAttrs>(&*op.attrs)) {
          for (const auto& field : inline_attrs->fields) {
            out << "      " << field.name << ": " << field.type;
            for (std::size_t i = 0; i < field.list_depth; ++i) out << "[]";
            if (field.optional) out << "?";
            if (field.empty_default) out << " = []";
            out << '\n';
          }
        }
      }
      if (op.dtype_definition)
        printMetadataDefinition(out, *op.dtype_definition, "dtype");
      if (op.shape_definition)
        printMetadataDefinition(out, *op.shape_definition);
      if (op.axes) {
        out << "      axes\n";
        for (const auto& statement : op.axes->statements) {
          if (const auto* binding = std::get_if<syntax::AxisBind>(&statement)) {
            out << "        bind " << binding->name << '\n';
            if (binding->domain) printMetadataExpr(out, *binding->domain, 5);
            for (const auto& entry : binding->bindings) {
              out << "          " << entry.operand << '\n';
              printMetadataExpr(out, *entry.positions, 6);
            }
          } else {
            const auto& metadata =
                std::get<syntax::MetadataStatement>(statement);
            if (const auto* local =
                    std::get_if<syntax::MetadataLet>(&metadata.value)) {
              out << "        let " << local->name << '\n';
              printMetadataExpr(out, *local->value, 5);
            } else {
              out << "        assert\n";
              printMetadataExpr(
                  out,
                  *std::get<syntax::MetadataAssert>(metadata.value).condition,
                  5);
            }
          }
        }
        out << "        yield\n";
        printMetadataExpr(out, *op.axes->output, 5);
      }
      if (op.semantics) {
        out << "      semantics";
        out << "\n";
        auto expression = [&](auto&& self, const syntax::SemanticExpr& e,
                              int depth) -> void {
          indent(out, depth);
          if (e.kind == syntax::SemanticExpr::Kind::kAttribute) out << "attrs.";
          out << e.text << '\n';
          for (const auto& arg : e.arguments) self(self, *arg, depth + 1);
        };
        out << "        yield\n";
        expression(expression, *op.semantics->result, 5);
      }
    }
  }
  for (const auto& rule : program.rules) {
    printRule(out, rule);
  }
  for (const auto& graph : program.graphs) {
    out << "  graph " << graph.name << '\n';
    for (const auto& input : graph.inputs) {
      out << "    input " << input.name;
      if (input.dtype) out << " dtype=" << input.dtype->name;
      if (input.shape) {
        out << " shape=[";
        for (std::size_t i = 0; i < input.shape->size(); ++i) {
          if (i) out << ", ";
          out << input.shape->at(i);
        }
        out << ']';
      }
      out << '\n';
    }
    std::function<void(const syntax::ConcreteExpr&)> expression =
        [&](const auto& expr) {
          if (expr.kind != syntax::ConcreteExpr::Kind::kOperation) {
            out << expr.name;
            if (expr.dtype) out << ':' << expr.dtype->name;
            return;
          }
          out << '(' << expr.name;
          if (!expr.attributes.empty()) {
            out << '[';
            std::function<void(const syntax::ConcreteValue&)> value =
                [&](const auto& item) {
                  if (item.kind == syntax::ConcreteValue::Kind::kList) {
                    out << '[';
                    for (std::size_t i = 0; i < item.elements.size(); ++i) {
                      if (i) out << ", ";
                      value(item.elements[i]);
                    }
                    out << ']';
                  } else if (item.kind == syntax::ConcreteValue::Kind::kString)
                    out << std::quoted(item.text);
                  else
                    out << item.text;
                };
            for (std::size_t i = 0; i < expr.attributes.size(); ++i) {
              if (i) out << ", ";
              out << expr.attributes[i].name << " = ";
              value(expr.attributes[i].value);
            }
            out << ']';
          }
          for (const auto& operand : expr.operands) {
            out << ' ';
            expression(operand);
          }
          out << ')';
        };
    for (const auto& binding : graph.bindings) {
      out << "    let " << binding.name << " = ";
      expression(binding.expression);
      out << '\n';
    }
    out << "    yield ";
    expression(graph.output);
    out << '\n';
  }
  return out.str();
}

}  // namespace tepl
