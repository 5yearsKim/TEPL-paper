#pragma once

#include <string>
#include <vector>

#include "src/executable/ir.h"

namespace tepl::codegen {

// Source identities and membership shared by every language backend. Names in
// paths are source names; each backend maps them to its own identifiers.
struct DialectPlan {
  std::string name;
  std::string source;
  std::vector<core::OpId> operations;
  std::vector<core::AttributeSchemaId> schemas;
};
struct ModulePlan {
  std::string source;
  std::vector<std::string> path;
  std::vector<core::RuleId> rules;
};
struct GraphModulePlan {
  std::string source;
  std::vector<std::string> path;
  std::vector<core::GraphId> graphs;
};
struct ProjectPlan {
  std::vector<DialectPlan> dialects;
  std::vector<ModulePlan> modules;
  std::vector<GraphModulePlan> graph_modules;
};

// Requires validated executable data. Rejects rule/graph sources outside their
// roots and ambiguous source module paths. Target-specific naming validation
// belongs to backends.
ProjectPlan planProject(const executable::ProgramData& program,
                        const std::string& rules_root = {},
                        const std::string& graphs_root = {});

}  // namespace tepl::codegen
