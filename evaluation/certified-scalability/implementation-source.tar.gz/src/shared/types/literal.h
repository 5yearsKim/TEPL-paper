#pragma once

#include <string_view>

#include "src/shared/types/types.h"

namespace tepl::core {

// Validate parsed literals without changing their spelling. Tensor floating
// format rounding/representability remains the host's responsibility.
bool validGraphLiteral(std::string_view spelling, DType dtype);
bool validScalarLiteral(std::string_view spelling, TypeKind type);

}  // namespace tepl::core
